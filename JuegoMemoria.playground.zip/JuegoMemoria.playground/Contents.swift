//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

for numero in 0 ... 100 {
    // vamos a excluir el cero
    if numero > 0 {
        
        if numero % 5 == 0 {
            print ("\(numero) Bingo !!!")
        }
    
        if numero % 2 == 0 {
            print ("\(numero) Es par !!!")
        }else {
            print ("\(numero) Es impar !!!")
        }
    
        if numero >= 30 && numero <= 40 {
            print ("\(numero) Viva Swift !!!" )
        }
    }else {
        print ("Excluimos al cero de la consulta")
    }
    
    
}